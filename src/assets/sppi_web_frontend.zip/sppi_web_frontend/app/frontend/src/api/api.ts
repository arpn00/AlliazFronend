const BACKEND_URI = "";

import { ChatAppResponse, ChatAppResponseOrError, PromptFlowRequest, Config, PromptFlowResponse } from "./models";
import { useLogin, appServicesToken } from "../authConfig";

function getHeaders(idToken: string | undefined): Record<string, string> {
    var headers: Record<string, string> = {
        "Content-Type": "application/json"
    };
    // If using login and not using app services, add the id token of the logged in account as the authorization
    if (useLogin && appServicesToken == null) {
        if (idToken) {
            headers["Authorization"] = `Bearer ${idToken}`;
        }
    }

    return headers;
}

export async function configApi(idToken: string | undefined): Promise<Config> {
    const response = await fetch(`${BACKEND_URI}/config`, {
        method: "GET",
        headers: getHeaders(idToken)
    });

    return (await response.json()) as Config;
}

export async function chatApi(request: PromptFlowRequest, idToken: string | undefined): Promise<PromptFlowResponse> {
    const response = await fetch(`${BACKEND_URI}/chat`, {
        method: "POST",
        headers: getHeaders(idToken),
        body: JSON.stringify(request)
    });

    return await response.json();
}

export function getCitationFilePath(citation: string): string {
    return `${BACKEND_URI}/content/${citation}`;
}

export async function getCitationForSelectedTask(taskId: string): Promise<any> {
    const response = await fetch(`/availableFiles/${taskId}`, {
        method: "GET"
    });
    var res = await response.json();
    return res;
}

export async function getAllAnalysisQuestion(evalCode: string | undefined): Promise<any> {
    try {
        const response = await fetch(`/datamanager/${evalCode}`, {
            method: "GET"
        });
        return await response.json();
    } catch {
        return [];
    }
}

export async function getEvalCodes(): Promise<any> {
    try {
        const response = await fetch(`/datamanager/eval_codes`, {
            method: "GET"
        });
        return await response.json();
    } catch {
        return [];
    }
}
