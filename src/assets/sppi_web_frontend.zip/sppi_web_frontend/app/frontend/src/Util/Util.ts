import { ChatAppResponse,CitationResponseBody, CitationResponse, getCitationForSelectedTask, PromptFlowRequest, PromptFlowResponse, ButtonsType, EvalCodeResponse } from "../api";
import { useLogin, appServicesToken } from "../authConfig";

export async function getCitationForAnswer(taskId: string, pages: string[]): Promise<CitationResponse[]> {

    let citationAnswers: CitationResponse[] = [];
    let citations: CitationResponseBody = await getCitationForSelectedTask(taskId);
    pages.map(x => {
        let name = x.split("||")[0].trim();
        let citationAnswer = citations.data.filter(y => y.name == name);
        citationAnswer[0].name = x;
        citationAnswers.push(citationAnswer[0]);
    });
    return citationAnswers;

}

export function createChatResponse(citations: CitationResponse[], message: string, buttons: ButtonsType[]): ChatAppResponse {

    let askResponse: ChatAppResponse = {
        choices: [
            {
                index: 0,
                buttons: buttons,
                context: {
                    data_points: citations,
                    followup_questions: null,
                    thoughts: []
                },
                session_state: null,
                message: {
                    content: message,
                    role: "assistant"
                }
            }
        ]
    } as ChatAppResponse;

    return askResponse;
}

export function createResponseBodyForPromptFlow(
    externalIdent: string | undefined, 
    question: string,
    userId: string,
    quotedOn : string | undefined,
    sessionId:string,
    chatId : string,
    questionType : string,
    importantNote?: string | undefined,
    searchText?: string | undefined): PromptFlowRequest {
 
    let request: PromptFlowRequest = {
        external_ident: externalIdent,
        chain_type: "map_rerank",
        max_token: 2048,
        question: question,
        important_note: importantNote === undefined ? "" : importantNote,
        session_id: sessionId,
        user_id: userId,
        chat_id: chatId,
        quoted_on: quotedOn,
        search_text: searchText === undefined ? "" : searchText,
        question_type :questionType
    };

    return request;
}