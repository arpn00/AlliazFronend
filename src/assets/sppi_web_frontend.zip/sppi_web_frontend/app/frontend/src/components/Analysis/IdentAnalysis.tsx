import { Stack } from "@fluentui/react/lib/Stack";
import { Text } from "@fluentui/react/lib/Text";
import { TextField } from "@fluentui/react/lib/TextField";
import { Dropdown, IDropdownOption } from "@fluentui/react/lib/Dropdown";
import { PrimaryButton } from "@fluentui/react/lib/Button";
import React from "react";
import { useState,useEffect } from "react";
import Chat from "../../pages/chat/Chat";
import { useLogin } from "../../authConfig";
import { LoginButton } from "../../components/LoginButton";
import { getRedirectUri, loginRequest } from "../../authConfig";
import { appServicesToken, appServicesLogout } from "../../authConfig";
import { useMsal } from "@azure/msal-react";
import {EvalCodeOptionsResponseBody, getEvalCodes} from "../../api"

const IdentAnalysis = () => {
    const [externalIdent, setexternalIdent] = useState<string>("");
    const [externalIdentType, setexternalIdentType] = useState<string | undefined>("");
    const [evalCode, setevalCode] = useState<string | undefined>("");
    const [mdValue, setmdValue] = useState<string | undefined>("");
    const [startChat, setStartChat] = useState<boolean>(false);

    const HandleExternalIdentChange = (event: any) => {
        setexternalIdent(event.target.value);
    };

    const HandleexternalIdentTypeChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => {
        setexternalIdentType(option?.text);
    };

    const HandleMdValueChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => {
        setmdValue(option?.text);
    };

    const HandleEvalCodeChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption, index?: number) => {
        setevalCode(option?.text);
    };

    const HandleSubmit = () => {
        setStartChat(true);
    };
    const HeaderStyles: React.CSSProperties = {
        color: "#605E5C",
        fontSize: "42px"
    };

    const UserHeaderStyles: React.CSSProperties = {
        color: "#605E5C",
        fontSize: "medium"
    };

    const ControlStyles: React.CSSProperties = {
        width: "250px"
    };

    const identTypesOptions: IDropdownOption[] = [{ key: "isin", text: "ISIN" }];
    const [evalCodesOptions, setEvalCodesOptions] = useState<IDropdownOption>([]);
       
    // const evalCodesOptions: IDropdownOption[] = [{ key: "rtgsensitive", text: "IS_RTG_SENSITIVE" }];

    const mdvalueOptions: IDropdownOption[] = [{ key: "y", text: "Y" }];

    const { instance } = useMsal();
    const activeAccount = instance.getActiveAccount();
    const isLoggedIn = (activeAccount || appServicesToken) != null;

    useEffect(() => {
        getEvalCodes().then((response: EvalCodeOptionsResponseBody) => {
            if (response.data !== undefined && Array.isArray(response.data) && response.data.length > 0) {
                let options : IDropdownOption[] =[];
                response.data.map((x:string) => {
                    options.push({ key: x, text: x });
                });
                setEvalCodesOptions(options);
            } else {
                // todo handle bad response and not available scenarios
            }
        });
    }, []);

    return (
        <div>
            {startChat ? (
                <Chat externalIdent={externalIdent} externalIdentType={externalIdentType} evalCode={evalCode} mdValue={mdValue}></Chat>
            ) : (
                <Stack enableScopedSelectors>
                    {isLoggedIn && useLogin && (
                        <Stack.Item align="end" style={{ paddingTop: "30px", paddingRight: "30px" }}>
                            <Text block style={UserHeaderStyles} variant="medium" nowrap>
                                <span>{`Hi ${activeAccount?.username ?? appServicesToken?.user_claims?.preferred_username}`}</span>
                            </Text>
                        </Stack.Item>
                    )}
                    <Stack.Item align="center" style={{ paddingTop: "5%", paddingBottom: "5%" }}>
                        <Text block style={HeaderStyles} variant="xxLarge" nowrap>
                            {isLoggedIn && useLogin ? (
                                <span>Start your SPPI Analysis</span>
                            ) : (
                                <span>
                                    Please login to get started<br></br>
                                    <LoginButton />
                                </span>
                            )}
                        </Text>
                    </Stack.Item>
                    {isLoggedIn && useLogin ? (
                        <Stack style={{ borderStyle: "solid", marginLeft: "200px", marginRight: "200px", borderColor: "#EDEDED" }}>
                            <Stack.Item align="center" tokens={{ padding: 20 }}>
                                <Text variant="xLarge" nowrap>
                                    External Ident
                                </Text>
                            </Stack.Item>
                            <Stack.Item align="center" tokens={{ padding: 20 }}>
                                <TextField style={ControlStyles} placeholder="Enter External Ident" onChange={HandleExternalIdentChange} />
                            </Stack.Item>
                            <Stack.Item align="center" tokens={{ padding: 20 }}>
                                <Dropdown
                                    placeholder="Select Types of External Ident"
                                    options={identTypesOptions}
                                    style={ControlStyles}
                                    onChange={HandleexternalIdentTypeChange}
                                />
                            </Stack.Item>
                            <Stack.Item align="center" tokens={{ padding: 20 }}>
                                <Dropdown placeholder="Enter Eval Code" options={evalCodesOptions} style={ControlStyles} onChange={HandleEvalCodeChange} />
                            </Stack.Item>
                            <Stack.Item align="center" tokens={{ padding: 20 }}>
                                <Dropdown placeholder="Enter MD Value" options={mdvalueOptions} style={ControlStyles} onChange={HandleMdValueChange} />
                            </Stack.Item>
                            <Stack.Item align="center" tokens={{ padding: 20 }}>
                                <PrimaryButton
                                    text="Continue"
                                    allowDisabledFocus
                                    checked={true}
                                    disabled={externalIdent == "" || externalIdentType == "" || mdValue == "" || evalCode == ""}
                                    onClick={HandleSubmit}
                                />
                            </Stack.Item>
                        </Stack>
                    ) : (
                        <></>
                    )}
                </Stack>
            )}
        </div>
    );
};

export default IdentAnalysis;
