import { useMemo } from "react";
import { Stack, IconButton } from "@fluentui/react";
import DOMPurify from "dompurify";
import styles from "./Answer.module.css";
import { ChatAppResponse } from "../../api";
import { AnswerIcon } from "./AnswerIcon";
import { getCitationFilePath } from "../../api";
import { CitationCard } from "../../components/Card/CitationCard";
import { ButtonsType } from "../../api";
import AnswerFeedback from "./AnswerFeedback";
import ChatButtons from "../Buttons/ChatButtons";

interface Props {
    answer: ChatAppResponse;
    isSelected?: boolean;
    isStreaming: boolean;
    buttons: ButtonsType[] | undefined;
    onCitationClicked: (filePath: string) => void;
    onChatButtonClicked: (buttonKey: string, buttonText: string) => void;
    showFooterText: boolean;
}

export const Answer = ({ answer, isSelected, isStreaming, buttons, onCitationClicked, onChatButtonClicked,showFooterText }: Props) => {
    const messageContent = answer.choices[0].message.content;
    const sanitizedAnswerHtml = DOMPurify.sanitize(messageContent);
    const citations = answer.choices[0].context.data_points;
    return (
        <>
            <Stack className={`${styles.answerContainer} ${isSelected && styles.selected}`} tokens={{ padding: 200 }} verticalAlign="space-between">
                <Stack.Item>
                    <Stack horizontal horizontalAlign="space-between">
                        <AnswerIcon />
                    </Stack>
                </Stack.Item>
                <Stack.Item grow>
                    <div className={styles.answerText} dangerouslySetInnerHTML={{ __html: sanitizedAnswerHtml }}></div>
                </Stack.Item>

                {citations.length > 0 && (
                    <Stack.Item>
                        <Stack tokens={{ childrenGap: 5 }}>
                            {citations.map((x, i) => {
                                const path = getCitationFilePath(x.link);
                                return (
                                    <a key={i} onClick={() => onCitationClicked(path)}>
                                         <CitationCard
                                            onCitationClicked={onCitationClicked}
                                            fileName= {x.name.indexOf("||") >=0 ? x.name.split("||")[0] : x.name}
                                            score={undefined}
                                            page={x.name.indexOf("||") >=0 ? x.name.split("||")[1] : undefined}
                                            refNumber={undefined}
                                            filePath={x.link}
                                        ></CitationCard>
                                    </a>
                                );
                            })}
                        </Stack>
                    </Stack.Item>
                )}
                 {showFooterText && (
                    <>
                        <br /> <br />
                        <strong>Do you agree with this result?</strong> <br /> <br />
                    </>
                )}
                {<ChatButtons buttons={buttons} onChatButtonClicked={onChatButtonClicked}></ChatButtons>}
                <AnswerFeedback />
            </Stack>
            <br></br>
        </>
    );
};